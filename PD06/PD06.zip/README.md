
# p1
mpic++ -fopenmp p1.cpp
python3 tester.py

# p2
g++ p2_1.cpp -fopenmp && ./a.out data.txt
g++ p2_2.cpp -fopenmp && ./a.out data.txt
